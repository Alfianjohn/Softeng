<div class="position-absolute top-50 start-50 translate-middle text-center">
    <div class="fw-bold fs-1 text-secondary">404 Not Found</div>
    <button onclick="history.go(-1)" class="btn btn-secondary mt-2">Kembali ke halaman sebelumnya</button>
</div>